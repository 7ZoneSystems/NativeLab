from nativelab.imports.import_global import Qt, QEvent, QWidget, QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox, QTextEdit, QTimer, pyqtSignal
from nativelab.UI.UI_global import C
from nativelab.GlobalConfig.config_global import DEFAULT_MODEL, MODELS_DIR
from nativelab.Model.model_global import (
    api_model_label,
    api_model_ref,
    detect_model_family,
    detect_quant_type,
    detect_vision_model,
    get_model_registry,
    getapi_registry,
    is_api_model_ref,
    quant_info,
)
from nativelab.UI.icons import set_button_icon

class InputBar(QWidget):
    send_requested       = pyqtSignal(str)
    stop_requested       = pyqtSignal()
    pdf_requested        = pyqtSignal()
    clear_requested      = pyqtSignal()
    pipeline_run_requested = pyqtSignal()
    load_model_requested = pyqtSignal()
    unload_model_requested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setObjectName("input_bar")
        root = QVBoxLayout()
        root.setContentsMargins(18, 12, 18, 14)
        root.setSpacing(9)

        toolbar = QHBoxLayout(); toolbar.setSpacing(8)

        self.model_card = QFrame()
        self.model_card.setObjectName("chat_model_card")
        model_card_l = QHBoxLayout(self.model_card)
        model_card_l.setContentsMargins(8, 4, 8, 4)
        model_card_l.setSpacing(8)
        model_lbl = QLabel("Model:")
        model_lbl.setStyleSheet(f"color:{C['txt2']};font-size:11px;")
        model_card_l.addWidget(model_lbl)
        self.model_combo = QComboBox()
        self.model_combo.setMinimumWidth(240)
        self.model_combo.setFixedHeight(28)
        self._populate_models()
        model_card_l.addWidget(self.model_combo, 1)

        self.family_badge = QLabel("")
        self.family_badge.setObjectName("family_badge")
        self.family_badge.setMinimumWidth(140)
        self.family_badge.setMaximumWidth(280)
        model_card_l.addWidget(self.family_badge)
        toolbar.addWidget(self.model_card, 1)

        self.load_model_btn = QPushButton("")
        set_button_icon(self.load_model_btn, "play", "", 18)
        self.load_model_btn.setFixedSize(38, 38)
        self.load_model_btn.setToolTip("Load the selected model")
        self.load_model_btn.clicked.connect(self.load_model_requested)
        toolbar.addWidget(self.load_model_btn)

        self.unload_model_btn = QPushButton("")
        set_button_icon(self.unload_model_btn, "power-off", "", 18)
        self.unload_model_btn.setFixedSize(38, 38)
        self.unload_model_btn.setToolTip("Unload the active chat model")
        self.unload_model_btn.clicked.connect(self.unload_model_requested)
        toolbar.addWidget(self.unload_model_btn)

        self.model_combo.currentIndexChanged.connect(self._update_family_badge)
        self.model_combo.currentIndexChanged.connect(self._on_model_combo_changed)
        toolbar.addStretch()

        self.pdf_btn   = QPushButton("PDF")
        self.clear_btn = QPushButton("Clear")
        set_button_icon(self.pdf_btn, "pdf", "PDF")
        set_button_icon(self.clear_btn, "clear", "Clear")
        for b in (self.pdf_btn, self.clear_btn):
            b.setFixedWidth(86); b.setFixedHeight(30)
        self.pdf_btn.clicked.connect(self.pdf_requested)
        self.clear_btn.clicked.connect(self.clear_requested)
        toolbar.addWidget(self.pdf_btn)
        toolbar.addWidget(self.clear_btn)

        self.skills_btn = QPushButton("Skills")
        set_button_icon(self.skills_btn, "lightbulb", "Skills")
        self.skills_btn.setFixedSize(86, 30)
        self.skills_btn.setCheckable(True)
        self.skills_btn.setToolTip("Enable active NativeLab skills for model calls")
        toolbar.addWidget(self.skills_btn)

        self.code_btn = QPushButton("Code")
        set_button_icon(self.code_btn, "code", "Code")
        self.code_btn.setFixedSize(80, 30)
        self.code_btn.setCheckable(True)
        self.code_btn.setObjectName("code_btn")
        self.code_btn.setToolTip(
            "Force coding engine for this message\n"
            "(auto-detects code keywords even when off)")
        toolbar.addWidget(self.code_btn)
        # Summary mode selector
        self.summary_mode_combo = QComboBox()
        self.summary_mode_combo.setFixedHeight(30)
        self.summary_mode_combo.setFixedWidth(110)
        self.summary_mode_combo.setObjectName("summary_combo")
        self.summary_mode_combo.addItem("Summary", "summary")
        self.summary_mode_combo.addItem("Logical", "logical")
        self.summary_mode_combo.addItem("Advice", "advice")
        self.summary_mode_combo.setToolTip(
            "Summary: standard summary\n"
            "Logical: mechanism/logic explained with structured points\n"
            "Advice: actionable advice based on the document")
        toolbar.addWidget(self.summary_mode_combo)
        # Pipeline mode indicator
        self.pipeline_badge = QLabel("")
        self.pipeline_badge.setObjectName("pipeline_badge")
        self.pipeline_badge.setVisible(False)
        toolbar.addWidget(self.pipeline_badge)

        root.addLayout(toolbar)

        row = QHBoxLayout(); row.setSpacing(10)
        self.input = QTextEdit()
        self.input.setPlaceholderText("Ask anything…   ↵ send   ⇧↵ newline")
        self.input.setMaximumHeight(120)
        self.input.setMinimumHeight(58)
        self.input.installEventFilter(self)

        self.send_btn = QPushButton("Send")
        set_button_icon(self.send_btn, "send", "Send", 18)
        self.send_btn.setObjectName("btn_send")
        self.send_btn.setFixedSize(90, 52)
        self.send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_btn.clicked.connect(self._emit_send)

        self.btn_pipeline_run = QPushButton("Pipeline")
        set_button_icon(self.btn_pipeline_run, "pipeline", "Pipeline")
        self.btn_pipeline_run.setObjectName("btn_pipeline")
        self.btn_pipeline_run.setFixedSize(100, 52)
        self.btn_pipeline_run.setToolTip("Run a saved pipeline on your current input")
        self.btn_pipeline_run.clicked.connect(self.pipeline_run_requested)
        self.btn_pipeline_run.setStyleSheet(
            f"QPushButton{{background:transparent;"
            f"color:{C['pipeline']};border:1px solid {C['pipeline']};"
            f"border-radius:6px;font-size:11px;font-weight:600;padding:0;}}"
            f"QPushButton:hover{{background:{C['pipeline']};color:#fff;}}")

        self.stop_btn = QPushButton("Stop")
        set_button_icon(self.stop_btn, "stop-circle", "Stop", 18)
        self.stop_btn.setObjectName("btn_stop")
        self.stop_btn.setFixedSize(90, 52)
        self.stop_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.stop_btn.setVisible(False)
        self.stop_btn.clicked.connect(self.stop_requested)

        action_row = QHBoxLayout()
        action_row.setContentsMargins(0, 0, 0, 0)
        action_row.setSpacing(10)
        action_row.setAlignment(Qt.AlignmentFlag.AlignTop)
        action_row.addWidget(self.send_btn)
        action_row.addWidget(self.btn_pipeline_run)
        action_row.addWidget(self.stop_btn)

        row.addWidget(self.input, 1)
        row.addLayout(action_row)
        root.addLayout(row)
        self.setLayout(root)
        self._update_family_badge()

    def _populate_models(self):
        self.model_combo.clear()
        for m in get_model_registry().all_models():
            self.model_combo.addItem(m["name"], m["path"])
        for cfg in getapi_registry().all():
            self.model_combo.addItem(api_model_label(cfg), api_model_ref(cfg.name))
        if self.model_combo.count() == 0:
            self.model_combo.addItem(DEFAULT_MODEL, str(MODELS_DIR / DEFAULT_MODEL))

    def _update_family_badge(self):
        path = self.model_combo.currentData() or ""
        if is_api_model_ref(path):
            cfg = getapi_registry().get_by_ref(path)
            if cfg:
                self.family_badge.setText(f"API  ·  {cfg.provider}  ·  max {cfg.max_tokens}")
            else:
                self.family_badge.setText("API")
            return
        if path:
            fam   = detect_model_family(path)
            quant = detect_quant_type(path)
            ql, _ = quant_info(quant)
            vi = detect_vision_model(path)
            vision = f"  ·  VLM: {vi.label}" if vi.is_vision else ""
            self.family_badge.setText(f"{fam.name}  ·  {quant}  ·  {ql}{vision}")
        else:
            self.family_badge.setText("")

    def _on_model_combo_changed(self, index: int):
        # Walk up to MainWindow so it can mark the newly selected model as pending.
        w = self.parent()
        while w and not hasattr(w, "_on_chat_model_selected"):
            w = w.parent()
        if w:
            on_selected = getattr(w, "_on_chat_model_selected", None)
            if on_selected:
                QTimer.singleShot(0, on_selected)

    def set_pipeline_mode(self, active: bool):
        active = bool(active)
        if not hasattr(self, "pipeline_badge") or self.pipeline_badge is None:
            return
        self.pipeline_badge.setVisible(active)
        if active:
            self.pipeline_badge.setText("Pipeline Mode")

    def eventFilter(self, obj, event):
        if obj is self.input and event.type() == QEvent.Type.KeyPress:
            if (event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)
                    and not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier)):
                self._emit_send()
                return True
        return super().eventFilter(obj, event)

    def _emit_send(self):
        text = self.input.toPlainText().strip()
        if text:
            self.input.clear()
            self.send_requested.emit(text)

    def set_generating(self, active: bool):
        self.send_btn.setVisible(not active)
        self.stop_btn.setVisible(active)
        self.input.setEnabled(not active)
        self.load_model_btn.setEnabled(not active)
        self.unload_model_btn.setEnabled(not active)
        self.skills_btn.setEnabled(not active)

    @property
    def selected_model(self) -> str:
        return self.model_combo.currentData() or ""

    @property
    def summary_mode(self) -> str:
        return self.summary_mode_combo.currentData() or "summary"

    @property
    def skills_enabled(self) -> bool:
        return self.skills_btn.isChecked()
